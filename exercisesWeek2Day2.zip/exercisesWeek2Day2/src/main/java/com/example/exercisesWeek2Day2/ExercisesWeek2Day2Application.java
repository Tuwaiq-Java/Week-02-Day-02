package com.example.exercisesWeek2Day2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercisesWeek2Day2Application {

	public static void main(String[] args) {
		SpringApplication.run(ExercisesWeek2Day2Application.class, args);
	}

}
